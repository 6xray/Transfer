package com.pathfinding.api;

/**
 * Paramètres d'entrée d'un appel au planificateur.
 *
 * <p>On regroupe ici tout ce qui ne dépend pas de l'algorithme choisi : le
 * monde, les contraintes cinétiques et la graine aléatoire pour les algos
 * sampling-based. Les algorithmes peuvent ignorer les champs qui ne les
 * concernent pas.</p>
 */
public record PathRequest(
        World world,
        KineticConstraints constraints,
        long randomSeed) {

    public static PathRequest of(World world, KineticConstraints constraints) {
        return new PathRequest(world, constraints, System.nanoTime());
    }

    public static PathRequest of(World world) {
        return of(world, KineticConstraints.UNCONSTRAINED);
    }
}
