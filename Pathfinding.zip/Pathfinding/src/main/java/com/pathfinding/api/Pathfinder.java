package com.pathfinding.api;

/**
 * Interface principale de la librairie. Un planificateur reçoit un
 * {@link PathRequest} (monde + contraintes + graine) et renvoie un
 * {@link PathResult} (chemin + statistiques de profilage).
 *
 * <p>L'interface est délibérément minimaliste pour faciliter l'ajout
 * d'algorithmes nouveaux : la seule responsabilité d'une implémentation est
 * de produire un PathResult.</p>
 */
public interface Pathfinder {

    /** Nom affiché dans l'UI et le benchmark. */
    String name();

    /** Calcule un chemin selon la requête. Doit toujours renvoyer un PathResult non null. */
    PathResult find(PathRequest request);

    /** Vrai si l'algorithme honore les contraintes cinétiques (angle maxi par pas). */
    default boolean supportsKinetic() { return false; }

    /** Vrai si l'algorithme requiert un monde de type grille discrète. */
    default boolean requiresGrid() { return false; }
}
