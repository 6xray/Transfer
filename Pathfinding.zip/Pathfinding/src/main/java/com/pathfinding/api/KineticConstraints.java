package com.pathfinding.api;

/**
 * Contraintes cinétiques d'un drone 2D.
 *
 * <p>Le cap du drone est discrétisé sur 8 directions (alignées avec les
 * voisins de grille) pour les algos discrets, et sur un cap continu pour les
 * algos sampling-based. Entre deux pas le cap ne peut varier que de
 * {@code maxTurnDegrees} degrés au maximum.</p>
 *
 * <p>Un poids de coût de virage {@code turnCostWeight} (≥ 0) ajoute une
 * pénalité proportionnelle à la déviation, pour encourager les trajectoires
 * lisses même quand un virage serré reste cinétiquement légal.</p>
 */
public final class KineticConstraints {

    /** Configuration par défaut "sans contrainte" : utile comme placeholder. */
    public static final KineticConstraints UNCONSTRAINED = new KineticConstraints(
            false, 180.0, false, 0.0, 0.0);

    private final boolean enabled;
    private final double maxTurnDegrees;
    private final boolean initialHeadingFixed;
    private final double initialHeadingDegrees;
    private final double turnCostWeight;

    public KineticConstraints(boolean enabled,
                              double maxTurnDegrees,
                              boolean initialHeadingFixed,
                              double initialHeadingDegrees,
                              double turnCostWeight) {
        if (maxTurnDegrees < 0 || maxTurnDegrees > 180) {
            throw new IllegalArgumentException("maxTurnDegrees ∈ [0,180]");
        }
        if (turnCostWeight < 0) {
            throw new IllegalArgumentException("turnCostWeight >= 0");
        }
        this.enabled = enabled;
        this.maxTurnDegrees = maxTurnDegrees;
        this.initialHeadingFixed = initialHeadingFixed;
        this.initialHeadingDegrees = initialHeadingDegrees;
        this.turnCostWeight = turnCostWeight;
    }

    public boolean enabled()                 { return enabled; }
    public double  maxTurnDegrees()          { return maxTurnDegrees; }
    public boolean initialHeadingFixed()     { return initialHeadingFixed; }
    public double  initialHeadingDegrees()   { return initialHeadingDegrees; }
    public double  turnCostWeight()          { return turnCostWeight; }
}
