package com.pathfinding.algorithms;

import com.pathfinding.algorithms.internal.IndexedMinHeap;
import com.pathfinding.api.GridLike;
import com.pathfinding.api.PathRequest;
import com.pathfinding.api.PathResult;
import com.pathfinding.api.Pathfinder;
import com.pathfinding.api.Vec2;
import com.pathfinding.api.World;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Jump Point Search optimisé.
 *
 * <p>Au lieu d'expanser chaque case voisine comme A*, JPS "saute" en ligne
 * droite tant qu'aucun "voisin forcé" n'apparaît (les voisins forcés
 * correspondent à des obstacles adjacents qui empêchent une réduction par
 * symétrie). Résultat : ordre de grandeur de moins d'expansions qu'A*-8 pour
 * le même chemin optimal sur grille uniforme.</p>
 *
 * <p>Optimisations par rapport à la version "classique" :
 * <ul>
 *   <li>Tas indexé + arrays primitifs (comme les A*).</li>
 *   <li>{@link #jump(int, int, int, int)} itératif (pas de récursion sur les
 *       axes). Les sauts diagonaux délèguent les sous-sauts axiaux à
 *       {@link #jumpAxial(int, int, int, int)}, lui aussi itératif.</li>
 *   <li>Retours encodés en int ({@code idx = x*H + y}, {@code -1} = non
 *       trouvé) au lieu de tableaux {@code int[2]} alloués à chaque appel.</li>
 * </ul>
 */
public final class JumpPointSearch implements Pathfinder {

    private GridLike grid;
    private int H;
    private int gx, gy;
    /** Cellules examinées par jump() / jumpAxial() — sert à la visualisation. */
    private List<Vec2> jumpExplored;

    @Override public String name() { return "Jump Point Search"; }

    @Override public boolean requiresGrid() { return true; }

    @Override
    public PathResult find(PathRequest req) {
        long t0 = System.nanoTime();
        PathResult.Builder rb = PathResult.builder().algorithmName(name());

        World w = req.world();
        if (!(w instanceof GridLike g)) {
            return rb.success(false).failureReason("JPS nécessite une grille discrète")
                    .elapsedNanos(System.nanoTime() - t0).build();
        }
        if (g.startCellX() < 0 || g.goalCellX() < 0) {
            return rb.success(false).failureReason("Départ ou arrivée non défini")
                    .elapsedNanos(System.nanoTime() - t0).build();
        }
        this.grid = g;
        this.H = g.gridHeight();
        this.gx = g.goalCellX();
        this.gy = g.goalCellY();
        this.jumpExplored = new ArrayList<>();

        int sx = g.startCellX(), sy = g.startCellY();
        int W = g.gridWidth();
        int N = W * H;

        double[] bestG  = new double[N];
        int[]    parent = new int[N];
        Arrays.fill(bestG, Double.POSITIVE_INFINITY);
        Arrays.fill(parent, -1);

        IndexedMinHeap open = new IndexedMinHeap(N);
        List<Vec2> explored = new ArrayList<>();
        int generated = 0, expanded = 0, maxOpen = 0;

        int startIdx = sx * H + sy;
        int goalIdx  = gx * H + gy;
        bestG[startIdx] = 0;
        open.insert(startIdx, AStar8.octile(sx, sy, gx, gy));
        generated++;

        while (!open.isEmpty()) {
            maxOpen = Math.max(maxOpen, open.size());
            int curIdx = open.extractMin();
            int cx = curIdx / H, cy = curIdx % H;
            expanded++;
            explored.add(Vec2.ofCellCenter(cx, cy));

            if (curIdx == goalIdx) {
                List<Vec2> raw = AStar4.reconstruct(parent, goalIdx, H);
                List<Vec2> dense = densify(raw);
                // explored visuel = jump points expansés + cellules visitées par jump()
                List<Vec2> totalExplored = new ArrayList<>(explored.size() + jumpExplored.size());
                totalExplored.addAll(explored);
                totalExplored.addAll(jumpExplored);
                rb.success(true).path(dense).explored(totalExplored)
                        .nodesExpanded(expanded).nodesGenerated(generated)
                        .maxOpenSize(maxOpen).elapsedNanos(System.nanoTime() - t0);
                PathResult.fillGeometry(rb, dense);
                return rb.build();
            }

            for (long dir : pruneDirections(parent, curIdx, cx, cy)) {
                int dx = (int) (dir >> 32);
                int dy = (int) dir;
                int jpIdx = jump(cx, cy, dx, dy);
                if (jpIdx < 0) continue;
                int jx = jpIdx / H, jy = jpIdx % H;
                double ng = bestG[curIdx] + AStar8.octile(cx, cy, jx, jy);
                if (ng < bestG[jpIdx]) {
                    bestG[jpIdx] = ng;
                    parent[jpIdx] = curIdx;
                    double f = ng + AStar8.octile(jx, jy, gx, gy);
                    if (!open.contains(jpIdx)) {
                        open.insert(jpIdx, f);
                        generated++;
                    } else {
                        open.decreaseKey(jpIdx, f);
                    }
                }
            }
        }

        List<Vec2> totalExplored = new ArrayList<>(explored.size() + jumpExplored.size());
        totalExplored.addAll(explored);
        totalExplored.addAll(jumpExplored);
        return rb.success(false).failureReason("Aucun chemin").explored(totalExplored)
                .nodesExpanded(expanded).nodesGenerated(generated).maxOpenSize(maxOpen)
                .elapsedNanos(System.nanoTime() - t0).build();
    }

    /**
     * Directions à explorer depuis un nœud, en tenant compte de la direction
     * d'arrivée et des voisins forcés. Encodage compact : chaque direction est
     * un {@code long} = {@code ((long)dx << 32) | (dy & 0xFFFFFFFF)}.
     */
    private long[] pruneDirections(int[] parent, int curIdx, int cx, int cy) {
        int parIdx = parent[curIdx];
        if (parIdx < 0) {
            // Racine : 8 directions
            long[] all = new long[8];
            int k = 0;
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    if (dx == 0 && dy == 0) continue;
                    all[k++] = pack(dx, dy);
                }
            }
            return all;
        }
        int pdx = Integer.signum(cx - parIdx / H);
        int pdy = Integer.signum(cy - parIdx % H);
        long[] dirs = new long[5];   // au pire : axe naturel + 2 axes + 2 forcés
        int k = 0;
        if (pdx != 0 && pdy != 0) {
            dirs[k++] = pack(pdx, 0);
            dirs[k++] = pack(0, pdy);
            dirs[k++] = pack(pdx, pdy);
            if (!grid.isFreeCell(cx - pdx, cy) && grid.isFreeCell(cx - pdx, cy + pdy))
                dirs[k++] = pack(-pdx, pdy);
            if (!grid.isFreeCell(cx, cy - pdy) && grid.isFreeCell(cx + pdx, cy - pdy))
                dirs[k++] = pack(pdx, -pdy);
        } else if (pdx != 0) {
            dirs[k++] = pack(pdx, 0);
            if (!grid.isFreeCell(cx, cy + 1) && grid.isFreeCell(cx + pdx, cy + 1)) dirs[k++] = pack(pdx, 1);
            if (!grid.isFreeCell(cx, cy - 1) && grid.isFreeCell(cx + pdx, cy - 1)) dirs[k++] = pack(pdx, -1);
        } else {
            dirs[k++] = pack(0, pdy);
            if (!grid.isFreeCell(cx + 1, cy) && grid.isFreeCell(cx + 1, cy + pdy)) dirs[k++] = pack(1, pdy);
            if (!grid.isFreeCell(cx - 1, cy) && grid.isFreeCell(cx - 1, cy + pdy)) dirs[k++] = pack(-1, pdy);
        }
        return Arrays.copyOf(dirs, k);
    }

    /**
     * Saut diagonal ou axial, itératif. Renvoie l'index du jump point trouvé
     * ({@code x*H + y}) ou {@code -1} si aucun point n'est rencontré.
     */
    private int jump(int x, int y, int dx, int dy) {
        // Si direction strictement axiale, on délègue tout de suite.
        if (dx == 0 || dy == 0) return jumpAxial(x, y, dx, dy);

        // Boucle diagonale : on avance (dx, dy) tant qu'on peut.
        while (true) {
            int nx = x + dx, ny = y + dy;
            if (!grid.isFreeCell(nx, ny)) return -1;
            if (!grid.isFreeCell(x + dx, y) && !grid.isFreeCell(x, y + dy)) return -1;  // corner cutting
            jumpExplored.add(Vec2.ofCellCenter(nx, ny));
            if (nx == gx && ny == gy) return nx * H + ny;
            // Voisins forcés diagonaux
            if ((!grid.isFreeCell(nx - dx, ny) && grid.isFreeCell(nx - dx, ny + dy))
                    || (!grid.isFreeCell(nx, ny - dy) && grid.isFreeCell(nx + dx, ny - dy))) {
                return nx * H + ny;
            }
            // Sous-sauts axiaux : si on trouve un point en avançant horizontal
            // ou vertical depuis (nx, ny), alors (nx, ny) est jump point.
            if (jumpAxial(nx, ny, dx, 0) >= 0) return nx * H + ny;
            if (jumpAxial(nx, ny, 0, dy) >= 0) return nx * H + ny;
            x = nx; y = ny;
        }
    }

    /** Saut axial (dx=0 ou dy=0) itératif. */
    private int jumpAxial(int x, int y, int dx, int dy) {
        while (true) {
            int nx = x + dx, ny = y + dy;
            if (!grid.isFreeCell(nx, ny)) return -1;
            jumpExplored.add(Vec2.ofCellCenter(nx, ny));
            if (nx == gx && ny == gy) return nx * H + ny;
            if (dx != 0) {
                if ((!grid.isFreeCell(nx, ny + 1) && grid.isFreeCell(nx + dx, ny + 1))
                        || (!grid.isFreeCell(nx, ny - 1) && grid.isFreeCell(nx + dx, ny - 1))) {
                    return nx * H + ny;
                }
            } else {
                if ((!grid.isFreeCell(nx + 1, ny) && grid.isFreeCell(nx + 1, ny + dy))
                        || (!grid.isFreeCell(nx - 1, ny) && grid.isFreeCell(nx - 1, ny + dy))) {
                    return nx * H + ny;
                }
            }
            x = nx; y = ny;
        }
    }

    private static long pack(int dx, int dy) {
        return ((long) dx << 32) | (dy & 0xFFFFFFFFL);
    }

    /** Remplit les cases intermédiaires entre jump points (pour le rendu). */
    private static List<Vec2> densify(List<Vec2> jumpPoints) {
        if (jumpPoints.size() < 2) return jumpPoints;
        List<Vec2> dense = new ArrayList<>();
        dense.add(jumpPoints.get(0));
        for (int i = 1; i < jumpPoints.size(); i++) {
            Vec2 a = jumpPoints.get(i - 1);
            Vec2 b = jumpPoints.get(i);
            int ax = (int) Math.floor(a.x()), ay = (int) Math.floor(a.y());
            int bx = (int) Math.floor(b.x()), by = (int) Math.floor(b.y());
            int sx = Integer.signum(bx - ax), sy = Integer.signum(by - ay);
            int x = ax, y = ay;
            while (x != bx || y != by) {
                x += sx; y += sy;
                dense.add(Vec2.ofCellCenter(x, y));
            }
        }
        return dense;
    }
}
