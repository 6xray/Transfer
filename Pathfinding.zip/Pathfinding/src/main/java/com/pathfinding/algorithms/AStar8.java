package com.pathfinding.algorithms;

import com.pathfinding.algorithms.internal.IndexedMinHeap;
import com.pathfinding.api.GridLike;
import com.pathfinding.api.PathRequest;
import com.pathfinding.api.PathResult;
import com.pathfinding.api.Pathfinder;
import com.pathfinding.api.Vec2;
import com.pathfinding.api.World;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * A* sur grille 8-connexe, heuristique octile, refus du corner-cutting.
 *
 * <p>Mêmes optimisations que {@link AStar4} : tas binaire indexé avec
 * decrease-key, arrays primitifs pour bestG et parent.</p>
 */
public final class AStar8 implements Pathfinder {

    private static final int[] DX = { 1, -1, 0,  0,  1,  1, -1, -1};
    private static final int[] DY = { 0,  0, 1, -1,  1, -1,  1, -1};
    private static final double SQRT2 = Math.sqrt(2);

    @Override public String name() { return "A* (8-dir, Octile)"; }

    @Override public boolean requiresGrid() { return true; }

    @Override
    public PathResult find(PathRequest req) {
        long t0 = System.nanoTime();
        PathResult.Builder rb = PathResult.builder().algorithmName(name());

        World w = req.world();
        if (!(w instanceof GridLike grid)) {
            return rb.success(false).failureReason("A*8 nécessite une grille discrète")
                    .elapsedNanos(System.nanoTime() - t0).build();
        }
        if (grid.startCellX() < 0 || grid.goalCellX() < 0) {
            return rb.success(false).failureReason("Départ ou arrivée non défini")
                    .elapsedNanos(System.nanoTime() - t0).build();
        }
        int sx = grid.startCellX(), sy = grid.startCellY();
        int gx = grid.goalCellX(),  gy = grid.goalCellY();
        int W = grid.gridWidth(), H = grid.gridHeight();
        int N = W * H;

        double[] bestG  = new double[N];
        int[]    parent = new int[N];
        Arrays.fill(bestG, Double.POSITIVE_INFINITY);
        Arrays.fill(parent, -1);

        IndexedMinHeap open = new IndexedMinHeap(N);
        List<Vec2> explored = new ArrayList<>();
        int generated = 0, expanded = 0, maxOpen = 0;

        int startIdx = sx * H + sy;
        int goalIdx  = gx * H + gy;
        bestG[startIdx] = 0;
        open.insert(startIdx, octile(sx, sy, gx, gy));
        generated++;

        while (!open.isEmpty()) {
            maxOpen = Math.max(maxOpen, open.size());
            int curIdx = open.extractMin();
            int cx = curIdx / H, cy = curIdx % H;
            expanded++;
            explored.add(Vec2.ofCellCenter(cx, cy));

            if (curIdx == goalIdx) {
                List<Vec2> path = AStar4.reconstruct(parent, goalIdx, H);
                rb.success(true).path(path).explored(explored)
                        .nodesExpanded(expanded).nodesGenerated(generated)
                        .maxOpenSize(maxOpen).elapsedNanos(System.nanoTime() - t0);
                PathResult.fillGeometry(rb, path);
                return rb.build();
            }

            double curG = bestG[curIdx];
            for (int i = 0; i < 8; i++) {
                int nx = cx + DX[i], ny = cy + DY[i];
                if (!grid.isFreeCell(nx, ny)) continue;
                // Refus du corner-cutting : les deux cases adjacentes au
                // mouvement diagonal doivent être libres.
                if (DX[i] != 0 && DY[i] != 0
                        && (!grid.isFreeCell(cx + DX[i], cy) || !grid.isFreeCell(cx, cy + DY[i]))) {
                    continue;
                }
                int nIdx = nx * H + ny;
                double step = (DX[i] != 0 && DY[i] != 0) ? SQRT2 : 1.0;
                double ng = curG + step;
                if (ng < bestG[nIdx]) {
                    bestG[nIdx] = ng;
                    parent[nIdx] = curIdx;
                    double f = ng + octile(nx, ny, gx, gy);
                    if (!open.contains(nIdx)) {
                        open.insert(nIdx, f);
                        generated++;
                    } else {
                        open.decreaseKey(nIdx, f);
                    }
                }
            }
        }

        return rb.success(false).failureReason("Aucun chemin").explored(explored)
                .nodesExpanded(expanded).nodesGenerated(generated).maxOpenSize(maxOpen)
                .elapsedNanos(System.nanoTime() - t0).build();
    }

    static double octile(int x0, int y0, int x1, int y1) {
        int dx = Math.abs(x0 - x1);
        int dy = Math.abs(y0 - y1);
        return (dx + dy) + (SQRT2 - 2) * Math.min(dx, dy);
    }
}
