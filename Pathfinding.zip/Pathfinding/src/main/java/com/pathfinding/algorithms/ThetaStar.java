package com.pathfinding.algorithms;

import com.pathfinding.algorithms.internal.IndexedMinHeap;
import com.pathfinding.api.GridLike;
import com.pathfinding.api.PathRequest;
import com.pathfinding.api.PathResult;
import com.pathfinding.api.Pathfinder;
import com.pathfinding.api.Vec2;
import com.pathfinding.api.World;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Theta* (any-angle) sur grille 8-connexe. À chaque relâchement on essaie de
 * rattacher le voisin au grand-parent du nœud courant si la visibilité directe
 * ({@link World#lineOfSight(Vec2, Vec2)}) le permet : par inégalité
 * triangulaire le coût via le grand-parent est toujours ≤ via le parent, donc
 * on peut systématiquement préférer ce raccourci.
 *
 * <p>Optimisations identiques aux variantes d'A* : tas indexé + arrays
 * primitifs + reconstruction par parent[]. La visibilité reste l'opération
 * dominante, c'est elle qui dicte le coût asymptotique.</p>
 */
public final class ThetaStar implements Pathfinder {

    private static final int[] DX = { 1, -1, 0,  0,  1,  1, -1, -1};
    private static final int[] DY = { 0,  0, 1, -1,  1, -1,  1, -1};

    @Override public String name() { return "Theta* (any-angle)"; }

    @Override public boolean requiresGrid() { return true; }

    @Override
    public PathResult find(PathRequest req) {
        long t0 = System.nanoTime();
        PathResult.Builder rb = PathResult.builder().algorithmName(name());

        World w = req.world();
        if (!(w instanceof GridLike grid)) {
            return rb.success(false).failureReason("Theta* nécessite une grille discrète")
                    .elapsedNanos(System.nanoTime() - t0).build();
        }
        if (grid.startCellX() < 0 || grid.goalCellX() < 0) {
            return rb.success(false).failureReason("Départ ou arrivée non défini")
                    .elapsedNanos(System.nanoTime() - t0).build();
        }
        int sx = grid.startCellX(), sy = grid.startCellY();
        int gx = grid.goalCellX(),  gy = grid.goalCellY();
        int W = grid.gridWidth(), H = grid.gridHeight();
        int N = W * H;

        double[] bestG  = new double[N];
        int[]    parent = new int[N];
        Arrays.fill(bestG, Double.POSITIVE_INFINITY);
        Arrays.fill(parent, -1);

        IndexedMinHeap open = new IndexedMinHeap(N);
        List<Vec2> explored = new ArrayList<>();
        int generated = 0, expanded = 0, maxOpen = 0;

        int startIdx = sx * H + sy;
        int goalIdx  = gx * H + gy;
        Vec2 goalV = Vec2.ofCellCenter(gx, gy);
        bestG[startIdx] = 0;
        // Le départ n'a pas de parent ; on note startIdx comme son propre parent
        // pour simplifier la règle Theta* (le grand-parent du départ n'existe pas).
        parent[startIdx] = startIdx;
        open.insert(startIdx, Vec2.ofCellCenter(sx, sy).distance(goalV));
        generated++;

        while (!open.isEmpty()) {
            maxOpen = Math.max(maxOpen, open.size());
            int curIdx = open.extractMin();
            int cx = curIdx / H, cy = curIdx % H;
            expanded++;
            Vec2 curV = Vec2.ofCellCenter(cx, cy);
            explored.add(curV);

            if (curIdx == goalIdx) {
                List<Vec2> path = reconstructTheta(parent, startIdx, goalIdx, H);
                rb.success(true).path(path).explored(explored)
                        .nodesExpanded(expanded).nodesGenerated(generated)
                        .maxOpenSize(maxOpen).elapsedNanos(System.nanoTime() - t0);
                PathResult.fillGeometry(rb, path);
                return rb.build();
            }

            int parIdx = parent[curIdx];
            Vec2 parV = Vec2.ofCellCenter(parIdx / H, parIdx % H);

            for (int i = 0; i < 8; i++) {
                int nx = cx + DX[i], ny = cy + DY[i];
                if (!grid.isFreeCell(nx, ny)) continue;
                if (DX[i] != 0 && DY[i] != 0
                        && (!grid.isFreeCell(cx + DX[i], cy) || !grid.isFreeCell(cx, cy + DY[i]))) {
                    continue;
                }
                int nIdx = nx * H + ny;
                Vec2 nV = Vec2.ofCellCenter(nx, ny);

                // Règle Theta* : si grand-parent → voisin est en vue,
                // on rattache au grand-parent (Path 2). Sinon A* standard (Path 1).
                int candParent;
                double candG;
                if (parIdx != curIdx && w.lineOfSight(parV, nV)) {
                    candParent = parIdx;
                    candG = bestG[parIdx] + parV.distance(nV);
                } else {
                    candParent = curIdx;
                    candG = bestG[curIdx] + curV.distance(nV);
                }
                if (candG < bestG[nIdx]) {
                    bestG[nIdx] = candG;
                    parent[nIdx] = candParent;
                    double f = candG + nV.distance(goalV);
                    if (!open.contains(nIdx)) {
                        open.insert(nIdx, f);
                        generated++;
                    } else {
                        open.decreaseKey(nIdx, f);
                    }
                }
            }
        }

        return rb.success(false).failureReason("Aucun chemin").explored(explored)
                .nodesExpanded(expanded).nodesGenerated(generated).maxOpenSize(maxOpen)
                .elapsedNanos(System.nanoTime() - t0).build();
    }

    /** Remontée de la chaîne parent[]. Le départ se référence lui-même : on s'arrête là. */
    private static List<Vec2> reconstructTheta(int[] parent, int startIdx, int goalIdx, int H) {
        List<Vec2> out = new ArrayList<>();
        int idx = goalIdx;
        while (true) {
            out.add(Vec2.ofCellCenter(idx / H, idx % H));
            if (idx == startIdx) break;
            int p = parent[idx];
            if (p == idx || p < 0) break;  // sécurité
            idx = p;
        }
        java.util.Collections.reverse(out);
        return out;
    }
}
