package com.pathfinding.algorithms;

import com.pathfinding.algorithms.internal.IndexedMinHeap;
import com.pathfinding.api.GridLike;
import com.pathfinding.api.PathRequest;
import com.pathfinding.api.PathResult;
import com.pathfinding.api.Pathfinder;
import com.pathfinding.api.Vec2;
import com.pathfinding.api.World;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * A* classique sur une grille 4-connexe, heuristique de Manhattan.
 *
 * <p>Version optimisée :
 * <ul>
 *   <li>Open set = {@link IndexedMinHeap} avec decrease-key en O(log n) :
 *       chaque case n'apparaît qu'une fois dans le tas (au lieu d'accumuler
 *       des entrées obsolètes "lazy-deleted" comme avec PriorityQueue).</li>
 *   <li>Closed set = {@code double[] bestG} primitif (accès O(1), pas
 *       d'auto-boxing Double).</li>
 *   <li>Reconstruction par {@code int[] parent} (indices) au lieu d'objets
 *       SearchNode chaînés : aucune allocation par expansion.</li>
 * </ul>
 */
public final class AStar4 implements Pathfinder {

    // Voisinage cardinal : Est, Ouest, Sud, Nord
    private static final int[] DX = {1, -1, 0, 0};
    private static final int[] DY = {0, 0, 1, -1};

    @Override public String name() { return "A* (4-dir, Manhattan)"; }

    @Override public boolean requiresGrid() { return true; }

    @Override
    public PathResult find(PathRequest req) {
        long t0 = System.nanoTime();
        PathResult.Builder rb = PathResult.builder().algorithmName(name());

        World w = req.world();
        if (!(w instanceof GridLike grid)) {
            return rb.success(false).failureReason("A*4 nécessite une grille discrète")
                    .elapsedNanos(System.nanoTime() - t0).build();
        }
        if (grid.startCellX() < 0 || grid.goalCellX() < 0) {
            return rb.success(false).failureReason("Départ ou arrivée non défini")
                    .elapsedNanos(System.nanoTime() - t0).build();
        }
        int sx = grid.startCellX(), sy = grid.startCellY();
        int gx = grid.goalCellX(),  gy = grid.goalCellY();
        int W = grid.gridWidth(), H = grid.gridHeight();
        int N = W * H;

        // Structures de données O(1) indexées par numéro de case (x*H + y).
        double[] bestG  = new double[N];
        int[]    parent = new int[N];
        Arrays.fill(bestG, Double.POSITIVE_INFINITY);
        Arrays.fill(parent, -1);

        IndexedMinHeap open = new IndexedMinHeap(N);
        List<Vec2> explored = new ArrayList<>();
        int generated = 0, expanded = 0, maxOpen = 0;

        int startIdx = sx * H + sy;
        int goalIdx  = gx * H + gy;
        bestG[startIdx] = 0;
        open.insert(startIdx, manhattan(sx, sy, gx, gy));
        generated++;

        while (!open.isEmpty()) {
            maxOpen = Math.max(maxOpen, open.size());
            int curIdx = open.extractMin();
            int cx = curIdx / H, cy = curIdx % H;
            expanded++;
            explored.add(Vec2.ofCellCenter(cx, cy));

            if (curIdx == goalIdx) {
                List<Vec2> path = reconstruct(parent, goalIdx, H);
                rb.success(true).path(path).explored(explored)
                        .nodesExpanded(expanded).nodesGenerated(generated)
                        .maxOpenSize(maxOpen).elapsedNanos(System.nanoTime() - t0);
                PathResult.fillGeometry(rb, path);
                return rb.build();
            }

            double curG = bestG[curIdx];
            for (int i = 0; i < 4; i++) {
                int nx = cx + DX[i], ny = cy + DY[i];
                if (!grid.isFreeCell(nx, ny)) continue;
                int nIdx = nx * H + ny;
                double ng = curG + 1.0;
                if (ng < bestG[nIdx]) {
                    bestG[nIdx] = ng;
                    parent[nIdx] = curIdx;
                    double f = ng + manhattan(nx, ny, gx, gy);
                    if (!open.contains(nIdx)) {
                        open.insert(nIdx, f);
                        generated++;
                    } else {
                        open.decreaseKey(nIdx, f);
                    }
                }
            }
        }

        return rb.success(false).failureReason("Aucun chemin").explored(explored)
                .nodesExpanded(expanded).nodesGenerated(generated).maxOpenSize(maxOpen)
                .elapsedNanos(System.nanoTime() - t0).build();
    }

    static double manhattan(int x0, int y0, int x1, int y1) {
        return Math.abs(x0 - x1) + Math.abs(y0 - y1);
    }

    /** Remonte la chaîne {@code parent[]} depuis l'arrivée pour reconstruire le chemin. */
    static List<Vec2> reconstruct(int[] parent, int goalIdx, int height) {
        List<Vec2> out = new ArrayList<>();
        for (int i = goalIdx; i >= 0; i = parent[i]) {
            out.add(Vec2.ofCellCenter(i / height, i % height));
        }
        Collections.reverse(out);
        return out;
    }
}
