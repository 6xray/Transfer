package com.pathfinding.algorithms;

import com.pathfinding.algorithms.internal.IndexedMinHeap;
import com.pathfinding.api.GridLike;
import com.pathfinding.api.KineticConstraints;
import com.pathfinding.api.PathRequest;
import com.pathfinding.api.PathResult;
import com.pathfinding.api.Pathfinder;
import com.pathfinding.api.Vec2;
import com.pathfinding.api.World;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * A* avec contraintes cinétiques. État de recherche {@code (x, y, cap)}, le
 * cap étant discrétisé sur 8 directions (alignées avec les voisins de grille).
 *
 * <p>Mêmes optimisations que les autres variantes : tas indexé +
 * {@code double[] bestG} + {@code int[] parent}, mais sur un espace d'états
 * 3D de taille {@code W * H * HEADINGS}.</p>
 *
 * <p>Effet de la contrainte : maxTurn=45° interdit tout virage à 90°. Le
 * poids de virage ajoute une pénalité douce pour lisser même quand un virage
 * serré est autorisé.</p>
 */
public final class AStarKinetic implements Pathfinder {

    private static final int HEADINGS = 8;
    // Directions ordonnées : E, NE, N, NW, W, SW, S, SE
    private static final int[] DX = { 1,  1, 0, -1, -1, -1,  0,  1};
    private static final int[] DY = { 0,  1, 1,  1,  0, -1, -1, -1};
    private static final double STEP_DEG = 360.0 / HEADINGS;
    private static final double SQRT2 = Math.sqrt(2);

    @Override public String name() { return "A* kinetic (heading-aware)"; }

    @Override public boolean supportsKinetic() { return true; }

    @Override public boolean requiresGrid() { return true; }

    @Override
    public PathResult find(PathRequest req) {
        long t0 = System.nanoTime();
        PathResult.Builder rb = PathResult.builder().algorithmName(name());

        World w = req.world();
        if (!(w instanceof GridLike grid)) {
            return rb.success(false).failureReason("A* kinetic nécessite une grille discrète")
                    .elapsedNanos(System.nanoTime() - t0).build();
        }
        if (grid.startCellX() < 0 || grid.goalCellX() < 0) {
            return rb.success(false).failureReason("Départ ou arrivée non défini")
                    .elapsedNanos(System.nanoTime() - t0).build();
        }
        int sx = grid.startCellX(), sy = grid.startCellY();
        int gx = grid.goalCellX(),  gy = grid.goalCellY();
        int W = grid.gridWidth(), H = grid.gridHeight();
        int N = W * H * HEADINGS;

        KineticConstraints kc = req.constraints();
        int maxSteps = (kc == null || !kc.enabled()) ? HEADINGS
                : (int) Math.floor(kc.maxTurnDegrees() / STEP_DEG + 1e-9);
        double turnCostWeight = (kc == null) ? 0.0 : kc.turnCostWeight();

        double[] bestG  = new double[N];
        int[]    parent = new int[N];
        Arrays.fill(bestG, Double.POSITIVE_INFINITY);
        Arrays.fill(parent, -1);

        IndexedMinHeap open = new IndexedMinHeap(N);
        List<Vec2> explored = new ArrayList<>();
        int generated = 0, expanded = 0, maxOpen = 0;

        // Caps initiaux : libres par défaut, fixés si demandé
        double h0 = octile(sx, sy, gx, gy);
        if (kc == null || !kc.initialHeadingFixed()) {
            for (int h = 0; h < HEADINGS; h++) {
                int idx = stateIdx(sx, sy, h, H);
                bestG[idx] = 0;
                open.insert(idx, h0);
                generated++;
            }
        } else {
            int h = headingFromDegrees(kc.initialHeadingDegrees());
            int idx = stateIdx(sx, sy, h, H);
            bestG[idx] = 0;
            open.insert(idx, h0);
            generated++;
        }

        while (!open.isEmpty()) {
            maxOpen = Math.max(maxOpen, open.size());
            int curIdx = open.extractMin();
            // décode (x, y, heading)
            int curHeading = curIdx % HEADINGS;
            int cellIdx    = curIdx / HEADINGS;
            int cx = cellIdx / H;
            int cy = cellIdx % H;
            expanded++;
            explored.add(Vec2.ofCellCenter(cx, cy));

            if (cx == gx && cy == gy) {
                List<Vec2> path = reconstruct(parent, curIdx, H);
                rb.success(true).path(path).explored(explored)
                        .nodesExpanded(expanded).nodesGenerated(generated)
                        .maxOpenSize(maxOpen).elapsedNanos(System.nanoTime() - t0);
                PathResult.fillGeometry(rb, path);
                return rb.build();
            }

            double curG = bestG[curIdx];

            for (int delta = -maxSteps; delta <= maxSteps; delta++) {
                int newHeading = Math.floorMod(curHeading + delta, HEADINGS);
                int nx = cx + DX[newHeading];
                int ny = cy + DY[newHeading];
                if (!grid.isFreeCell(nx, ny)) continue;
                if (DX[newHeading] != 0 && DY[newHeading] != 0
                        && (!grid.isFreeCell(cx + DX[newHeading], cy)
                            || !grid.isFreeCell(cx, cy + DY[newHeading]))) {
                    continue;
                }
                double step = (DX[newHeading] != 0 && DY[newHeading] != 0) ? SQRT2 : 1.0;
                double turnPenalty = turnCostWeight * Math.abs(delta) * STEP_DEG / 180.0;
                double ng = curG + step + turnPenalty;
                int nIdx = stateIdx(nx, ny, newHeading, H);
                if (ng < bestG[nIdx]) {
                    bestG[nIdx] = ng;
                    parent[nIdx] = curIdx;
                    double f = ng + octile(nx, ny, gx, gy);
                    if (!open.contains(nIdx)) {
                        open.insert(nIdx, f);
                        generated++;
                    } else {
                        open.decreaseKey(nIdx, f);
                    }
                }
            }
        }

        return rb.success(false).failureReason("Aucun chemin (kinetic)").explored(explored)
                .nodesExpanded(expanded).nodesGenerated(generated).maxOpenSize(maxOpen)
                .elapsedNanos(System.nanoTime() - t0).build();
    }

    private static int stateIdx(int x, int y, int heading, int height) {
        return (x * height + y) * HEADINGS + heading;
    }

    private static int headingFromDegrees(double deg) {
        double a = ((deg % 360) + 360) % 360;
        return ((int) Math.round(a / STEP_DEG)) % HEADINGS;
    }

    private static double octile(int x0, int y0, int x1, int y1) {
        int dx = Math.abs(x0 - x1);
        int dy = Math.abs(y0 - y1);
        return (dx + dy) + (SQRT2 - 2) * Math.min(dx, dy);
    }

    private static List<Vec2> reconstruct(int[] parent, int goalState, int height) {
        List<Vec2> out = new ArrayList<>();
        for (int idx = goalState; idx >= 0; idx = parent[idx]) {
            int cellIdx = idx / HEADINGS;
            out.add(Vec2.ofCellCenter(cellIdx / height, cellIdx % height));
        }
        Collections.reverse(out);
        return out;
    }
}
