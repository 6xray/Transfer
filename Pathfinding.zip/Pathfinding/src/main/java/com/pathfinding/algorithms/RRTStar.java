package com.pathfinding.algorithms;

import com.pathfinding.algorithms.internal.KdTree;
import com.pathfinding.api.Bounds;
import com.pathfinding.api.PathRequest;
import com.pathfinding.api.PathResult;
import com.pathfinding.api.Pathfinder;
import com.pathfinding.api.Vec2;
import com.pathfinding.api.World;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * RRT* (Karaman & Frazzoli 2011) — version "asymptotiquement optimale" du RRT.
 *
 * <p>Optimisation principale ici : la requête "voisin le plus proche" et la
 * requête "voisins dans un rayon" passent par un {@link KdTree} (O(log n) en
 * moyenne) au lieu d'un balayage linéaire O(n) sur la liste de l'arbre.
 * Avec 3000 itérations on passe d'environ 10⁷ comparaisons à 10⁴, soit un
 * facteur 100 sur cette partie.</p>
 *
 * <p>L'algorithme reste reconnaissable :
 * <ol>
 *   <li>échantillon {@code q_rand}</li>
 *   <li>plus proche voisin → steer → vérif visibilité → {@code q_new}</li>
 *   <li>choose-parent : meilleur parent dans le rayon</li>
 *   <li>rewire : améliore les voisins déjà présents si {@code q_new} fait mieux</li>
 *   <li>tente la connexion finale au but</li>
 * </ol>
 */
public final class RRTStar implements Pathfinder {

    private final int maxIterations;
    private final double stepSize;
    private final double goalBias;
    private final double rewireRadius;
    private final double goalThreshold;

    public RRTStar() {
        this(3000, 1.5, 0.10, 3.0, 1.0);
    }

    public RRTStar(int maxIterations, double stepSize, double goalBias,
                   double rewireRadius, double goalThreshold) {
        this.maxIterations = maxIterations;
        this.stepSize = stepSize;
        this.goalBias = goalBias;
        this.rewireRadius = rewireRadius;
        this.goalThreshold = goalThreshold;
    }

    @Override public String name() { return "RRT*"; }

    @Override
    public PathResult find(PathRequest req) {
        long t0 = System.nanoTime();
        PathResult.Builder rb = PathResult.builder().algorithmName(name());

        World w = req.world();
        Vec2 start = w.start();
        Vec2 goal  = w.goal();
        if (start == null || goal == null) {
            return rb.success(false).failureReason("Départ ou arrivée non défini")
                    .elapsedNanos(System.nanoTime() - t0).build();
        }

        Random rng = new Random(req.randomSeed());
        Bounds B = w.bounds();

        // Stockage de l'arbre : positions, parents et coûts dans des arrays "parallèles".
        // KdTree pour les requêtes spatiales rapides.
        List<TreeNode> tree = new ArrayList<>(maxIterations + 1);
        KdTree spatial = new KdTree();
        tree.add(new TreeNode(start, -1, 0));
        spatial.insert(start, 0);

        int bestGoalParent = -1;
        double bestGoalCost = Double.POSITIVE_INFINITY;

        int expanded = 0, generated = 1;
        List<Integer> nearBuf = new ArrayList<>();  // réutilisé entre itérations

        for (int iter = 0; iter < maxIterations; iter++) {
            // (1) Échantillon avec biais vers le goal
            Vec2 qRand = (rng.nextDouble() < goalBias) ? goal : sampleFree(w, B, rng);
            if (qRand == null) continue;

            // (2) Plus proche voisin via KdTree (O(log n))
            int nearestIdx = spatial.nearest(qRand);
            TreeNode nearest = tree.get(nearestIdx);

            // (3) Steer + test visibilité
            Vec2 qNew = steer(nearest.position, qRand, stepSize);
            if (!w.isFree(qNew) || !w.lineOfSight(nearest.position, qNew)) continue;
            expanded++;

            // (4) Choose-parent : voisins dans rayon via KdTree
            nearBuf.clear();
            spatial.range(qNew, rewireRadius, nearBuf::add);

            int bestParent = nearestIdx;
            double bestCost = nearest.cost + nearest.position.distance(qNew);
            for (int i = 0, n = nearBuf.size(); i < n; i++) {
                int idx = nearBuf.get(i);
                if (idx == nearestIdx) continue;
                TreeNode cand = tree.get(idx);
                double c = cand.cost + cand.position.distance(qNew);
                if (c < bestCost && w.lineOfSight(cand.position, qNew)) {
                    bestParent = idx;
                    bestCost = c;
                }
            }

            int newIdx = tree.size();
            tree.add(new TreeNode(qNew, bestParent, bestCost));
            spatial.insert(qNew, newIdx);
            generated++;

            // (5) Rewire : qNew peut-il devenir un meilleur parent pour des voisins existants ?
            for (int i = 0, n = nearBuf.size(); i < n; i++) {
                int idx = nearBuf.get(i);
                if (idx == bestParent) continue;
                TreeNode cand = tree.get(idx);
                double c = bestCost + qNew.distance(cand.position);
                if (c < cand.cost && w.lineOfSight(qNew, cand.position)) {
                    cand.parent = newIdx;
                    cand.cost = c;
                }
            }

            // (6) Connexion finale
            if (qNew.distance(goal) <= goalThreshold && w.lineOfSight(qNew, goal)) {
                double total = bestCost + qNew.distance(goal);
                if (total < bestGoalCost) {
                    bestGoalCost = total;
                    bestGoalParent = newIdx;
                }
            }
        }

        // Pour la visualisation : tous les nœuds de l'arbre
        List<Vec2> explored = new ArrayList<>(tree.size());
        for (TreeNode n : tree) explored.add(n.position);

        if (bestGoalParent < 0) {
            return rb.success(false).failureReason("Pas de chemin trouvé en " + maxIterations + " itérations")
                    .explored(explored)
                    .nodesExpanded(expanded).nodesGenerated(generated)
                    .elapsedNanos(System.nanoTime() - t0).build();
        }

        List<Vec2> path = reconstruct(tree, bestGoalParent, goal);
        rb.success(true).path(path).explored(explored)
                .nodesExpanded(expanded).nodesGenerated(generated)
                .maxOpenSize(generated).elapsedNanos(System.nanoTime() - t0);
        PathResult.fillGeometry(rb, path);
        return rb.build();
    }

    static Vec2 sampleFree(World w, Bounds B, Random rng) {
        for (int i = 0; i < 30; i++) {
            double x = B.minX() + rng.nextDouble() * B.width();
            double y = B.minY() + rng.nextDouble() * B.height();
            Vec2 v = new Vec2(x, y);
            if (w.isFree(v)) return v;
        }
        return null;
    }

    static Vec2 steer(Vec2 from, Vec2 to, double max) {
        double d = from.distance(to);
        if (d <= max) return to;
        Vec2 dir = to.sub(from).normalized();
        return from.add(dir.scale(max));
    }

    static List<Vec2> reconstruct(List<TreeNode> tree, int parentOfGoal, Vec2 goal) {
        List<Vec2> out = new ArrayList<>();
        out.add(goal);
        for (int idx = parentOfGoal; idx >= 0; idx = tree.get(idx).parent) {
            out.add(tree.get(idx).position);
        }
        Collections.reverse(out);
        return out;
    }

    /** Nœud d'arbre RRT* — visible par {@link ThetaStarRRT} via le package. */
    static final class TreeNode {
        final Vec2 position;
        int parent;
        double cost;
        TreeNode(Vec2 position, int parent, double cost) {
            this.position = position;
            this.parent = parent;
            this.cost = cost;
        }
    }
}
