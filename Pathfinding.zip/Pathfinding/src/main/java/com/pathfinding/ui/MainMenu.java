package com.pathfinding.ui;

import com.pathfinding.ui.continuous.ContinuousEditorFrame;
import com.pathfinding.ui.grid.GridEditorFrame;
import com.pathfinding.ui.theme.Card;
import com.pathfinding.ui.theme.PillButton;
import com.pathfinding.ui.theme.Screen;
import com.pathfinding.ui.theme.Theme;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.RenderingHints;

/**
 * Menu principal de l'application. Présente deux grandes cartes : "Grille" et
 * "Carte continue". Chaque carte mène à son éditeur dédié.
 */
public final class MainMenu extends JFrame {

    private static MainMenu instance;

    public static void open() {
        if (instance == null) instance = new MainMenu();
        instance.setVisible(true);
        instance.toFront();
    }

    private MainMenu() {
        super("Pathfinding · Studio");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setBackground(Theme.BG_WINDOW);
        ((JPanel) getContentPane()).setBorder(BorderFactory.createEmptyBorder(
                Theme.PADDING_LG, Theme.PADDING_LG, Theme.PADDING_LG, Theme.PADDING_LG));
        setLayout(new BorderLayout(0, Theme.PADDING_LG));
        add(buildHeader(), BorderLayout.NORTH);
        add(buildCards(), BorderLayout.CENTER);
        add(buildFooter(), BorderLayout.SOUTH);
        // Dimensionnement adaptatif (proportionnel à l'écran, plancher 700×420).
        setSize(Screen.menuSize());
        setMinimumSize(new Dimension(720, 440));
        setLocationRelativeTo(null);
    }

    private JPanel buildHeader() {
        JPanel head = new JPanel();
        head.setLayout(new BoxLayout(head, BoxLayout.Y_AXIS));
        head.setOpaque(false);

        JLabel eyebrow = new JLabel("PATHFINDING STUDIO");
        eyebrow.setFont(Theme.FONT_CAPTION.deriveFont(Font.BOLD));
        eyebrow.setForeground(Theme.ACCENT);
        eyebrow.setAlignmentX(LEFT_ALIGNMENT);

        JLabel title = new JLabel("Choisis un environnement");
        title.setFont(Theme.FONT_TITLE_XL);
        title.setForeground(Theme.TEXT_PRIMARY);
        title.setAlignmentX(LEFT_ALIGNMENT);

        JLabel sub = new JLabel(
                "<html><body style='width:560px'>Compare sept algorithmes "
              + "(A* 4-dir, A* 8-dir, Theta*, JPS, A* kinetic, RRT*, Theta*-RRT*) "
              + "sur une grille discrète ou sur une carte continue à obstacles "
              + "polygonaux. Sélectionne le mode adapté à ton scénario.</body></html>");
        sub.setFont(Theme.FONT_BODY);
        sub.setForeground(Theme.TEXT_SECONDARY);
        sub.setAlignmentX(LEFT_ALIGNMENT);

        head.add(eyebrow);
        head.add(Box.createRigidArea(new Dimension(0, 6)));
        head.add(title);
        head.add(Box.createRigidArea(new Dimension(0, 6)));
        head.add(sub);
        return head;
    }

    private JPanel buildCards() {
        JPanel row = new JPanel(new GridLayout(1, 2, Theme.PADDING_LG, 0));
        row.setOpaque(false);

        row.add(buildModeCard(
                "GRILLE DISCRÈTE",
                "Mode grille",
                "Quadrillage rectangulaire de cases. Cinq algorithmes A* (4-dir, 8-dir, Theta*, JPS, kinetic) + sampling-based RRT*/Theta*-RRT*. Idéal pour des cartes type tile-based.",
                Theme.ACCENT,
                () -> { setVisible(false); new GridEditorFrame().setVisible(true); }
        ));

        row.add(buildModeCard(
                "CARTE CONTINUE",
                "Mode continu",
                "Espace 2D à coordonnées réelles peuplé d'obstacles polygonaux (formes non cubiques). Seuls les algos sampling-based (RRT*, Theta*-RRT*) y opèrent.",
                Theme.VIOLET,
                () -> { setVisible(false); new ContinuousEditorFrame().setVisible(true); }
        ));

        return row;
    }

    private JPanel buildModeCard(String eyebrow, String title, String body,
                                  Color accent, Runnable action) {
        Card card = new Card();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));

        // Bandeau coloré décoratif en haut de la carte
        JPanel banner = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int w = getWidth(), h = getHeight();
                g2.setPaint(new GradientPaint(0, 0, accent, w, h, accent.darker()));
                g2.fillRoundRect(0, 0, w, h, 12, 12);
                g2.dispose();
            }
        };
        banner.setOpaque(false);
        banner.setMaximumSize(new Dimension(Integer.MAX_VALUE, 110));
        banner.setPreferredSize(new Dimension(0, 110));
        banner.setAlignmentX(LEFT_ALIGNMENT);

        JLabel eyebrowLabel = new JLabel(eyebrow);
        eyebrowLabel.setFont(Theme.FONT_CAPTION.deriveFont(Font.BOLD));
        eyebrowLabel.setForeground(accent);
        eyebrowLabel.setAlignmentX(LEFT_ALIGNMENT);

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(Theme.FONT_TITLE);
        titleLabel.setForeground(Theme.TEXT_PRIMARY);
        titleLabel.setAlignmentX(LEFT_ALIGNMENT);

        JLabel bodyLabel = new JLabel("<html><body style='width:340px'>" + body + "</body></html>");
        bodyLabel.setFont(Theme.FONT_BODY);
        bodyLabel.setForeground(Theme.TEXT_SECONDARY);
        bodyLabel.setAlignmentX(LEFT_ALIGNMENT);

        PillButton openBtn = new PillButton("Ouvrir →", PillButton.Style.PRIMARY);
        openBtn.addActionListener(e -> action.run());
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        btnRow.setOpaque(false);
        btnRow.setAlignmentX(LEFT_ALIGNMENT);
        btnRow.add(openBtn);

        card.add(banner);
        card.add(Box.createRigidArea(new Dimension(0, Theme.PADDING_MD)));
        card.add(eyebrowLabel);
        card.add(Box.createRigidArea(new Dimension(0, 4)));
        card.add(titleLabel);
        card.add(Box.createRigidArea(new Dimension(0, 8)));
        card.add(bodyLabel);
        card.add(Box.createVerticalGlue());
        card.add(btnRow);

        return card;
    }

    private JPanel buildFooter() {
        JLabel l = new JLabel("Java " + System.getProperty("java.version")
                + " · Drone Pathfinding Prototype");
        l.setFont(Theme.FONT_CAPTION);
        l.setForeground(Theme.TEXT_SECONDARY);
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        p.setOpaque(false);
        p.add(l);
        return p;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Theme.applyGlobalDefaults();
            open();
        });
    }
}
