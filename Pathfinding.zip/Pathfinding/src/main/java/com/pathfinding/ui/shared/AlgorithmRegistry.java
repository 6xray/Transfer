package com.pathfinding.ui.shared;

import com.pathfinding.algorithms.AStar4;
import com.pathfinding.algorithms.AStar8;
import com.pathfinding.algorithms.AStarKinetic;
import com.pathfinding.algorithms.JumpPointSearch;
import com.pathfinding.algorithms.RRTStar;
import com.pathfinding.algorithms.ThetaStar;
import com.pathfinding.algorithms.ThetaStarRRT;
import com.pathfinding.api.Pathfinder;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/**
 * Catalogue centralisé des algorithmes disponibles. Chaque algo y est déclaré
 * une seule fois, avec son fournisseur (les algos sampling-based sont
 * stateless donc on peut les recréer à chaque appel) et un booléen indiquant
 * s'ils requièrent une grille.
 *
 * <p>L'UI consomme cette registry plutôt que de hard-coder la liste, ce qui
 * rend l'ajout d'un nouvel algo trivial.</p>
 */
public final class AlgorithmRegistry {

    public record Entry(String name, boolean requiresGrid, Supplier<Pathfinder> factory) {
        public Pathfinder build() { return factory.get(); }
    }

    private static final List<Entry> ENTRIES = List.of(
            new Entry("A* (4-dir)",      true,  AStar4::new),
            new Entry("A* (8-dir)",      true,  AStar8::new),
            new Entry("Theta*",          true,  ThetaStar::new),
            new Entry("Jump Point Search", true, JumpPointSearch::new),
            new Entry("A* kinetic",      true,  AStarKinetic::new),
            new Entry("RRT*",            false, RRTStar::new),
            new Entry("Theta*-RRT*",     false, ThetaStarRRT::new)
    );

    private AlgorithmRegistry() {}

    public static List<Entry> all() { return ENTRIES; }

    public static List<Entry> forGrid() {
        return ENTRIES;
    }

    /**
     * Pour le mode continu on expose les 7 algorithmes : ceux qui exigent une
     * grille seront exécutés sur une rasterisation à la volée
     * ({@link com.pathfinding.world.Discretizer}). C'est à l'UI de déclencher
     * la discrétisation au moment du run.
     */
    public static List<Entry> forContinuous() {
        return ENTRIES;
    }
}
