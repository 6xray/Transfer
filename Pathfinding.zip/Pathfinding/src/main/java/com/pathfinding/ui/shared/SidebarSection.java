package com.pathfinding.ui.shared;

import com.pathfinding.ui.theme.Theme;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Dimension;

/**
 * Petit conteneur pour une section de la barre latérale : un titre en
 * majuscules grisé et un empilement vertical d'éléments. Donne le rythme
 * visuel "type Preferences pane" caractéristique des UIs Apple.
 */
public final class SidebarSection extends JPanel {

    public SidebarSection(String title) {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setOpaque(false);
        setAlignmentX(LEFT_ALIGNMENT);

        JLabel header = new JLabel(title.toUpperCase());
        header.setFont(Theme.FONT_CAPTION.deriveFont(java.awt.Font.BOLD));
        header.setForeground(Theme.TEXT_SECONDARY);
        header.setAlignmentX(LEFT_ALIGNMENT);
        header.setBorder(BorderFactory.createEmptyBorder(0, 0, 6, 0));
        add(header);
    }

    public SidebarSection row(JComponent c) {
        if (c instanceof JComponent jc) jc.setAlignmentX(LEFT_ALIGNMENT);
        c.setMaximumSize(new Dimension(Integer.MAX_VALUE, c.getPreferredSize().height));
        add(c);
        add(Box.createRigidArea(new Dimension(0, 6)));
        return this;
    }

    public SidebarSection gap(int h) {
        add(Box.createRigidArea(new Dimension(0, h)));
        return this;
    }
}
