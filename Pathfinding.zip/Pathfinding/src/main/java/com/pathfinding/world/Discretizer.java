package com.pathfinding.world;

import com.pathfinding.api.Vec2;

/**
 * Rasterisation d'un {@link ContinuousWorld} en {@link GridWorld}. Sert à
 * faire tourner les algorithmes "grille seulement" (A*4, A*8, Theta*, JPS,
 * A* kinetic) sur une carte continue : on échantillonne le centre de chaque
 * case et on la marque comme obstacle si elle tombe dans un polygone.
 *
 * <p>Le {@code cellSize} contrôle la résolution : plus il est petit, plus la
 * grille est fine mais plus le coût de calcul grandit (en O(W·H / cellSize²)).</p>
 */
public final class Discretizer {

    private Discretizer() {}

    public static GridWorld rasterize(ContinuousWorld cw, double cellSize) {
        if (cellSize <= 0) throw new IllegalArgumentException("cellSize > 0");
        double W = cw.bounds().width();
        double H = cw.bounds().height();
        int gw = Math.max(1, (int) Math.ceil(W / cellSize));
        int gh = Math.max(1, (int) Math.ceil(H / cellSize));

        GridWorld grid = new GridWorld(gw, gh);

        // 1) Marque chaque case dont le centre tombe dans un obstacle ou hors limites.
        for (int x = 0; x < gw; x++) {
            for (int y = 0; y < gh; y++) {
                double cx = (x + 0.5) * cellSize;
                double cy = (y + 0.5) * cellSize;
                if (!cw.isFree(new Vec2(cx, cy))) {
                    grid.setObstacle(x, y, true);
                }
            }
        }

        // 2) Place le départ et l'arrivée. Si la case correspondante est marquée
        //    obstacle (artefact d'arrondi), on la libère pour ne pas bloquer la
        //    recherche : les positions continues sont garanties valides côté
        //    ContinuousWorld.
        if (cw.start() != null) {
            int sx = clamp((int) Math.floor(cw.start().x() / cellSize), 0, gw - 1);
            int sy = clamp((int) Math.floor(cw.start().y() / cellSize), 0, gh - 1);
            grid.setObstacle(sx, sy, false);
            grid.setStart(sx, sy);
        }
        if (cw.goal() != null) {
            int gxC = clamp((int) Math.floor(cw.goal().x() / cellSize), 0, gw - 1);
            int gyC = clamp((int) Math.floor(cw.goal().y() / cellSize), 0, gh - 1);
            grid.setObstacle(gxC, gyC, false);
            grid.setGoal(gxC, gyC);
        }

        return grid;
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
