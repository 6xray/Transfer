# Drone Pathfinding Prototype

A Java 21 prototype for 2D drone path planning. Provides an editable grid,
multiple A* variants, kinetic (turn-angle) constraints, and a side-by-side
benchmark / profiling harness — all in a single Swing application.

## Features

- **Editable grid** — resize freely, place start/goal, draw obstacles of any
  shape (click-and-drag to paint), erase, clear.
- **Five A\* variants**, swap from the side panel:
  - `A* (4-dir, Manhattan)` — classical reference.
  - `A* (8-dir, Octile)` — diagonal moves, no corner-cutting through walls.
  - `Theta*` — any-angle pathfinding; parents are inherited from grandparents
    when a Bresenham line-of-sight is clear. Produces visually shortest paths.
  - `Jump Point Search` — symmetric-path-reduction optimisation of A* on
    uniform-cost grids. Same path quality as `A* 8-dir` but typically
    explores an order of magnitude fewer expansions.
  - `A* kinetic` — search state is `(x, y, heading)`. The drone's heading is
    discretised into 8 directions; only heading changes within
    `maxTurnDegrees` per step are allowed. An optional turn-cost weight biases
    the search toward smoother trajectories.
- **Kinetic constraints** — max turn per step, optional pinned initial
  heading, configurable turn-cost weight. A 45° max turn forbids 90° corners,
  matching realistic drone limits.
- **Benchmark harness** — runs every registered algorithm `N` times,
  discards the first run (JIT warm-up), and reports per-algorithm:
  - elapsed time (avg / min / max / σ)
  - nodes expanded, nodes generated, max open-set size
  - path length, total turn (°), turn count
  - and a "best-of" summary (fastest / fewest expansions / shortest /
    smoothest).

## Project layout

```
src/main/java/com/pathfinding/
├── Main.java
├── core/                  Grid, Cell, Position
├── algorithms/            Pathfinder + 5 implementations + shared types
├── kinetic/               KineticConstraints
├── benchmark/             Benchmark + BenchmarkResult
└── ui/                    Swing UI (MainFrame, GridPanel, ControlPanel, ResultsPanel)
```

## Requirements

- JDK 21 or newer.
- Apache Maven 3.9+ (optional — can also compile by hand, see below).

## Build / run with Maven

```powershell
mvn -q package
mvn -q exec:java
```

The packaged jar is `target/drone-pathfinder.jar`:

```powershell
java -jar target/drone-pathfinder.jar
```

## Build / run without Maven (hand-compile)

From the project root:

```powershell
# Compile
$src = Get-ChildItem -Recurse -Filter *.java src/main/java | ForEach-Object { $_.FullName }
javac -d out --release 21 $src

# Run
java -cp out com.pathfinding.Main
```

Bash equivalent:

```bash
find src/main/java -name "*.java" > sources.txt
javac -d out --release 21 @sources.txt
java -cp out com.pathfinding.Main
```

## Usage

1. **Place endpoints.** Click *Start* radio, click a cell. Same for *Goal*.
2. **Draw obstacles.** Click *Obstacle* radio, left-click-drag to paint walls,
   right-click-drag to erase. Obstacles can be any shape.
3. **Pick an algorithm** from the dropdown, then *Run selected algorithm*.
   The found path appears as a blue polyline.
4. **Toggle kinetic constraints** — only `A* kinetic` honours them (the other
   algorithms ignore the field; they are still useful for comparison). With
   max-turn = 45° you'll see the kinetic path avoid sharp 90° corners.
5. **Benchmark** — run all five algorithms `N` times in a row and inspect the
   results table at the bottom.

## Choosing a variant for your use case

| Need                                          | Best choice                  |
| ---                                           | ---                          |
| Smoothest, most realistic drone path          | `A* kinetic` (turn ≤ 45°)    |
| Shortest geometric path through open terrain  | `Theta*`                     |
| Fastest A* on a uniform-cost open grid        | `Jump Point Search`          |
| Baseline / reference                          | `A* (8-dir)`                 |
| Pedagogical / debugging                       | `A* (4-dir)`                 |

For a drone, `A* kinetic` is the production candidate; `Theta*` and `JPS` are
useful baselines (Theta* gives the optimal *unconstrained* path, JPS gives
the fastest exploration).

## Implementation notes

- Theta*'s line-of-sight is a standard Bresenham walk; it does not block
  corner-cutting between two diagonal obstacles. If your real-world use case
  forbids "wall-grazing" diagonals, the LOS check in `Grid.lineOfSight` can be
  tightened.
- `A* kinetic` discretises heading at 8 directions to align with grid
  neighbours. A finer heading granularity would require modelling moves that
  span multiple cells (a "lattice planner"), which is a natural extension.
- Benchmark timings are wall-clock via `System.nanoTime`. The first run is
  discarded to absorb JIT warm-up. Run with more iterations
  (`Bench runs` ≥ 20) for stable averages.
